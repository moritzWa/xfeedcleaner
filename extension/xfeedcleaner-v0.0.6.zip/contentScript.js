/* empty css                     */const N=document.createElement("style");N.textContent=`
  #xfeedcleaner * {
    all: unset;
  }

  #xfeedcleaner ul {
    list-style-type: disc !important;
    margin: 0 !important;
    padding-left: 20px !important;
  }

  #xfeedcleaner li {
  display: list-item !important;
    margin: 0.5em 0 !important;
  }

  #xfeedcleaner a {
    cursor: pointer;
  }

  #xfeedcleaner hr {
    height: 1px !important;
    border: none !important;
    padding: 0 !important;
    background-color: var(--black) !important;
  }
`;document.head.appendChild(N);const C=document.createElement("link");C.type="text/css";C.rel="stylesheet";document.head.appendChild(C);const I=document.createElement("style");I.textContent=`
  .xfc-controls {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    z-index: 1000;
  }

  .xfc-show-tweet-button {
    background-color: white;
    color: black;
    padding: 8px 16px;
    border-radius: 20px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    cursor: pointer;
    font-family: system-ui;
  }

  .xfc-reasons {
    color: #666;
    font-size: 12px;
    text-align: center;
    white-space: nowrap;
    font-family: system-ui;
    background: rgba(255, 255, 255, 0.9);
    padding: 4px 8px;
    border-radius: 4px;
  }

  .xfc-tweet-container {
    position: relative;
  }

  .xfc-tweet.hidden-tweet {
    display: none !important;
  }
`;document.head.appendChild(I);function g(...t){console.log("[xfc]",...t)}const b=new Map;function L(t){const e=t.closest('[data-testid="cellInnerDiv"]');if(!e)return{hasConnectorAbove:!1,hasConnectorBelow:!1};let o=!1,r=!1;const s=e.getBoundingClientRect(),f=t.getBoundingClientRect(),l=e.querySelectorAll("div");for(const n of l){const i=n.getBoundingClientRect();if(i.width===0||i.height===0||i.width>10||i.left>f.left+100)continue;const m=getComputedStyle(n).backgroundColor;if(m==="transparent"||m==="rgba(0, 0, 0, 0)")continue;const x=25,w=15;i.top<=s.top+x&&i.height>=2&&(o=!0),i.bottom>=s.bottom-w&&i.height>=15&&(r=!0)}if(!o){const n=e.previousElementSibling;if((n==null?void 0:n.getAttribute("data-testid"))==="cellInnerDiv"){const i=n.querySelector('[data-testid="tweet"]');(i==null?void 0:i.getAttribute("data-has-connector-below"))==="true"&&(o=!0)}}return{hasConnectorAbove:o,hasConnectorBelow:r}}function q(t){var i,a,m;const e=t.closest('[data-testid="cellInnerDiv"]');if(!e)return null;const o=e.previousElementSibling;if(!o||o.getAttribute("data-testid")!=="cellInnerDiv")return null;const r=o.querySelector('[data-testid="tweet"]');if(!r)return null;const s=r.querySelector('[data-testid="tweetText"]'),f=r.querySelector('[data-testid="User-Name"]'),l=((i=s==null?void 0:s.textContent)==null?void 0:i.trim())||"";return`[Parent @${((m=(a=f==null?void 0:f.textContent)==null?void 0:a.split("·")[0])==null?void 0:m.trim())||""}: ${l}]`}function R(t){var S;function e(c,d){const p=[];return c.getAttribute("data-testid")===d&&p.push(c),c.childNodes.forEach(u=>{u instanceof Element&&p.push(...e(u,d))}),p}function o(c){let d="";return c.childNodes.forEach(p=>{var u;p.nodeType===Node.TEXT_NODE?d+=((u=p.textContent)==null?void 0:u.trim())+" ":p instanceof Element&&(d+=o(p)+" ")}),d.trim()}const s=e(t,"tweetText").map(c=>o(c)).join(" ").trim(),n=e(t,"User-Name").map(c=>o(c)).join(" ").split(/[·\n]/).map(c=>c.trim()).filter(c=>c)[0]||"",i=[];e(t,"tweetPhoto").forEach(c=>{const d=p=>{p.childNodes.forEach(u=>{if(u instanceof Element){if(u.tagName==="IMG"){const h=u.getAttribute("src");if(h&&!h.includes("profile")){const k=h.replace(/\?format=\w+&name=\w+/,"?format=jpg&name=large");i.push(k)}}d(u)}})};d(c)});const m=[];e(t,"videoPlayer").forEach(c=>{const d=p=>{p.childNodes.forEach(u=>{if(u instanceof Element){if(u.tagName==="VIDEO"){const h=u.getAttribute("src");h&&m.push(h)}if(u.tagName==="SOURCE"){const h=u.getAttribute("src");h&&m.push(h)}d(u)}})};d(c)});const x=[],w=t.getElementsByTagName("a");Array.from(w).forEach(c=>{const d=c.getAttribute("href");d!=null&&d.startsWith("https://")&&!d.includes("twitter.com")&&x.push(d)});const M=((S=t.getElementsByTagName("time")[0])==null?void 0:S.getAttribute("datetime"))||"",A={replies:"0",reposts:"0",likes:"0",views:"0"};Object.entries({reply:"replies",retweet:"reposts",like:"likes",analytics:"views"}).forEach(([c,d])=>{const p=e(t,c);if(p.length>0){const u=o(p[0]);u&&(A[d]=u)}});const T=Math.random().toString(36).substring(7);return t.setAttribute("data-tweet-id",T),{text:s,author:n,images:i,videos:m,urls:x,timestamp:M,metrics:A,id:T}}const v=new IntersectionObserver(t=>{t.forEach(e=>{const o=e.target;if(e.isIntersecting){if(!o.hasAttribute("data-processed")){const r=R(o),s=L(o);g("Tweet processed:",{author:r.author,text:r.text.slice(0,50)+"...",threadInfo:s});let f=r.text;if(s.hasConnectorAbove){const a=q(o);a&&(f=`${a} [Reply @${r.author}: ${r.text}]`,g("Combined context:",f.slice(0,100)+"..."))}const l=o.closest('[data-testid="cellInnerDiv"]');let n=null,i=null;if(s.hasConnectorAbove&&l){const a=l.previousElementSibling;(a==null?void 0:a.getAttribute("data-testid"))==="cellInnerDiv"&&(n=a.querySelector('[data-testid="tweet"]'))}if(s.hasConnectorBelow&&l){const a=l.nextElementSibling;(a==null?void 0:a.getAttribute("data-testid"))==="cellInnerDiv"&&(i=a.querySelector('[data-testid="tweet"]'))}if(b.set(r.id,{element:o,parentElement:n,replyElement:i}),n){const a=n.getAttribute("data-tweet-id");if(a&&b.has(a)){const m=b.get(a);m.replyElement=o}}g("Stored connection:",{id:r.id,hasParent:!!n,hasReply:!!i}),chrome.runtime.sendMessage({action:"newTweet",content:{...r,text:f,isReply:s.hasConnectorAbove,hasReplyBelow:s.hasConnectorBelow}}),o.setAttribute("data-processed","true")}v.unobserve(o)}})},{threshold:.3,rootMargin:"100px"}),D=new MutationObserver(t=>{t.forEach(e=>{e.addedNodes.forEach(o=>{o instanceof HTMLElement&&o.querySelectorAll('[data-testid="tweet"]:not([data-processed])').forEach(s=>{v.observe(s)})})})});(window.location.hostname==="twitter.com"||window.location.hostname==="x.com")&&(D.observe(document.body,{childList:!0,subtree:!0}),document.querySelectorAll('[data-testid="tweet"]:not([data-processed])').forEach(e=>{v.observe(e)}));function y(t,e){var f;if(t.classList.contains("xfc-tweet"))return;const o=document.createElement("div");o.className="xfc-tweet-container",(f=t.parentNode)==null||f.insertBefore(o,t),o.appendChild(t);const r=document.createElement("div");r.className="xfc-controls",o.appendChild(r);const s=document.createElement("button");if(s.className="xfc-show-tweet-button",s.textContent="Show",r.appendChild(s),e&&e.length>0){const l=document.createElement("div");l.className="xfc-reasons",l.textContent=`Filtered: ${e.join(", ")}`,r.appendChild(l)}t.classList.add("xfc-tweet"),t.style.filter="blur(12px)",s.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation(),t.style.filter="none",t.classList.remove("xfc-tweet"),r.remove()})}function E(t){t.classList.contains("xfc-tweet")||t.classList.add("xfc-tweet","hidden-tweet")}chrome.runtime.onMessage.addListener(t=>{if(t.action==="analysisResult"){const{tweetId:e,isBait:o,error:r}=t.result;if(r){console.error(`Error analyzing tweet ${e}:`,r);return}const s=document.querySelector(`[data-tweet-id="${e}"]`);s&&o&&chrome.storage.sync.get(["displayMode"],f=>{const l=f.displayMode||"blur",n=b.get(e);g("Filtering tweet:",{tweetId:e,hasConnection:!!n,hasParent:!!(n!=null&&n.parentElement),hasReply:!!(n!=null&&n.replyElement)}),l==="blur"?y(s,t.result.reasons):E(s),n!=null&&n.parentElement&&(g("Hiding parent tweet (from stored reference)"),l==="blur"?y(n.parentElement,["thread filtered"]):E(n.parentElement)),n!=null&&n.replyElement&&(g("Hiding reply tweet (from stored reference)"),l==="blur"?y(n.replyElement,["thread filtered"]):E(n.replyElement))})}});chrome.runtime.onMessage.addListener(t=>{t.action==="toggleExtension"&&(t.isEnabled||(document.querySelectorAll(".xfc-tweet").forEach(e=>{e.style.filter="none",e.classList.remove("xfc-tweet")}),document.querySelectorAll(".xfc-show-tweet-button").forEach(e=>{e.remove()})))});
