(function(){"use strict";const l=`FILTER these types of tweets:
- Engagement bait: rage bait, thirst traps, "hot take", "agree or disagree?", ratio requests
- Vapid musings: "ugh mondays", "vibes", trend-riding with no actual thought or insight
- Electoral politics: elections, political parties, candidates, voting, partisan debates
- Culture war content: racism debates, immigration policy, DEI controversy, left vs right ideology
- Low-effort replies: emoji-only, "this", "lol", "+1", "W", "L", "ratio"
- Generic complaints: "is X down?", venting without substance
- Celebrity gossip, sports drama, reality TV

DO NOT FILTER (always allow):
- Tech, programming, software, AI/ML, startups, founder content
- Economics, finance, markets, investing, business news, global trade
- Intellectual discussion: philosophy, science, rationality, ideas
- Wisdom, quotes, or life lessons - especially from founders, investors, or notable figures
- Productivity, self-improvement, or life philosophy with actual insight
- Product announcements, tutorials, tips, workflows
- Personal projects, side projects, open source
- Hiring posts, career advice, industry analysis
- Book recommendations, learning resources
- Original thoughts and opinions on any allowed topic above

Note: Economics and business news mentioning governments or politicians in economic context is NOT political content - allow it.`,c="https://unbaited.moritzwa.deno.dev/analyze";async function u(o,t,r){const s=new AbortController,e=setTimeout(()=>s.abort(),r);try{const n=await fetch(o,{...t,signal:s.signal});return clearTimeout(e),n}catch(n){throw clearTimeout(e),n}}async function g(o){let t=null;for(let s=1;s<=5;s++)try{console.log(`🤖 Analysis attempt ${s}/5 for tweet ${o.tweetId}`);const e=await u(c,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)},1e4);if(console.log(`📡 Response status: ${e.status} ${e.statusText}`),!e.ok){const i=await e.text().catch(()=>"No error details");throw console.log(`❌ Server error (${e.status}):`,i),new Error(`Server returned ${e.status}: ${e.statusText}`)}const n=await e.json();return console.log("✅ Analysis successful:",n),n}catch(e){if(t=e,e instanceof Error&&(e.name==="AbortError"?console.log(`⏱️ Request timeout (attempt ${s}/5)`):e.message.includes("Failed to fetch")?console.log(`🌐 Network error - likely serverless cold start (attempt ${s}/5):`,e.message):console.log(`❌ Analysis error (attempt ${s}/5):`,e.message)),s<5){const n=1e3*Math.pow(2,s-1);console.log(`⏳ Retrying in ${n}ms... (exponential backoff)`),await new Promise(i=>setTimeout(i,n))}}console.error("💥 All 5 attempts failed. Last error:",t);let r="Failed to connect to analysis service.";return(t==null?void 0:t.name)==="AbortError"?r="Request timed out after multiple attempts. Please try again.":t!=null&&t.message.includes("Failed to fetch")&&(r="Network error - server may be starting up. Please try again in a moment."),{error:r}}typeof browser>"u"&&(globalThis.browser=chrome);async function d(o,t,r,s=[]){try{console.log("Analyzing tweet:",{tweetId:t,text:o,imageCount:s.length});const{promptCriteria:e}=await browser.storage.sync.get(["promptCriteria"]);console.log("Retrieved settings:",{hasCriteria:!!e});const i=await g({tweetText:o,tweetId:t,author:r,images:s,criteria:e||l});if("error"in i)return{tweetId:t,isBait:!1,error:i.error,debugInfo:{tweetText:o,author:r,images:s}};const a=i;return{tweetId:t,isBait:a.filter,reason:a.reason,debugInfo:{tweetText:o,author:r,images:s}}}catch(e){return console.error("Error analyzing tweet:",e),{tweetId:t,isBait:!1,error:e.message||"Unknown error",debugInfo:{tweetText:o,author:r,images:s}}}}browser.runtime.onMessage.addListener((o,t)=>(o.action==="newTweet"&&browser.storage.sync.get(["isEnabled"]).then(async r=>{if(!(r.isEnabled??!0))return;const e=o.content.id,n=o.content.author||"",i=o.content.images||[];d(o.content.text,e,n,i).then(a=>{console.log("Analysis result:",a),t.tab&&t.tab.id&&browser.tabs.sendMessage(t.tab.id,{action:"analysisResult",result:{tweetId:e,isBait:a.isBait,reason:a.reason,debugInfo:a.debugInfo,error:a.error||null}})})}),!0)),browser.runtime.onInstalled.addListener(async()=>{const{promptCriteria:o}=await browser.storage.sync.get(["promptCriteria"]),t={...o?{}:{promptCriteria:l},isEnabled:!0};Object.keys(t).length>0&&(await browser.storage.sync.set(t),console.log("Default settings set:",t))})})();
