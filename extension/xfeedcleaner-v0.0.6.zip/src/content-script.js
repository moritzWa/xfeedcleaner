(function(){"use strict";function S(n){const o=n.closest('[data-testid="cellInnerDiv"]');if(!o)return{hasConnectorAbove:!1,hasConnectorBelow:!1};let t=!1,e=!1;const s=o.getBoundingClientRect(),c=n.getBoundingClientRect(),r=o.querySelectorAll("div");for(const i of r){const a=i.getBoundingClientRect();if(a.width===0||a.height===0||a.width>10||a.left>c.left+100)continue;const d=getComputedStyle(i).backgroundColor;if(d==="transparent"||d==="rgba(0, 0, 0, 0)")continue;const u=25,g=15;a.top<=s.top+u&&a.height>=2&&(t=!0),a.bottom>=s.bottom-g&&a.height>=15&&(e=!0)}if(!t){const i=o.previousElementSibling;if((i==null?void 0:i.getAttribute("data-testid"))==="cellInnerDiv"){const a=i.querySelector('[data-testid="tweet"]');(a==null?void 0:a.getAttribute("data-has-connector-below"))==="true"&&(t=!0)}}return{hasConnectorAbove:t,hasConnectorBelow:e}}function j(n){var e,s,c;const o=[];let t=n.closest('[data-testid="cellInnerDiv"]');for(;t;){const r=t.previousElementSibling;if(!r||r.getAttribute("data-testid")!=="cellInnerDiv")break;const i=r.querySelector('[data-testid="tweet"]');if(!i)break;let a=i.getAttribute("data-has-connector-below")==="true";a||(a=S(i).hasConnectorBelow);const h=i.querySelector('[data-testid="tweetText"]'),d=i.querySelector('[data-testid="User-Name"]'),l=((e=h==null?void 0:h.textContent)==null?void 0:e.trim())||"",u=((c=(s=d==null?void 0:d.textContent)==null?void 0:s.split("·")[0])==null?void 0:c.trim())||"";if(o.unshift(`[Thread @${u}: ${l}]`),!a)break;t=r}return o}function v(n,o){const t=[];return n.getAttribute("data-testid")===o&&t.push(n),n.childNodes.forEach(e=>{e instanceof Element&&t.push(...v(e,o))}),t}function T(n){let o="";return n.childNodes.forEach(t=>{var e;t.nodeType===Node.TEXT_NODE?o+=((e=t.textContent)==null?void 0:e.trim())+" ":t instanceof Element&&(o+=T(t)+" ")}),o.trim()}function W(n){var P;const t=v(n,"tweetText").map(f=>T(f)).join(" ").trim(),c=v(n,"User-Name").map(f=>T(f)).join(" ").split(/[·\n]/).map(f=>f.trim()).filter(f=>f)[0]||"",r=[];v(n,"tweetPhoto").forEach(f=>{const p=b=>{b.childNodes.forEach(m=>{if(m instanceof Element){if(m.tagName==="IMG"){const x=m.getAttribute("src");if(x&&!x.includes("profile")){const M=x.replace(/\?format=\w+&name=\w+/,"?format=jpg&name=large");r.push(M)}}p(m)}})};p(f)});const a=[];v(n,"videoPlayer").forEach(f=>{const p=b=>{b.childNodes.forEach(m=>{if(m instanceof Element){if(m.tagName==="VIDEO"){const x=m.getAttribute("src");x&&a.push(x)}if(m.tagName==="SOURCE"){const x=m.getAttribute("src");x&&a.push(x)}p(m)}})};p(f)});const d=[],l=n.getElementsByTagName("a");Array.from(l).forEach(f=>{const p=f.getAttribute("href");p!=null&&p.startsWith("https://")&&!p.includes("twitter.com")&&d.push(p)});let u="";const g=v(n,"article-cover-image");if(g.length>0){const f=g[0],p=f.parentElement;if(p){const b=Array.from(p.children),m=b.indexOf(f);for(let x=m+1;x<b.length;x++){const M=b[x],z=T(M);z&&(u+=z+" ")}}u=u.trim()}const y=((P=n.getElementsByTagName("time")[0])==null?void 0:P.getAttribute("datetime"))||"",E={replies:"0",reposts:"0",likes:"0",views:"0"};Object.entries({reply:"replies",retweet:"reposts",like:"likes",analytics:"views"}).forEach(([f,p])=>{const b=v(n,f);if(b.length>0){const m=T(b[0]);m&&(E[p]=m)}});const k=Math.random().toString(36).substring(7);return n.setAttribute("data-tweet-id",k),{text:t,author:c,images:r,videos:a,urls:d,timestamp:y,metrics:E,id:k,articleText:u}}function G(n){const o=[n],t=n.closest('[data-testid="cellInnerDiv"]');if(!t)return o;let e=t;for(;e;){const c=e.previousElementSibling;if(!c||c.getAttribute("data-testid")!=="cellInnerDiv")break;const r=c.querySelector('[data-testid="tweet"]');if(!r||!(r.getAttribute("data-has-connector-below")==="true"||S(r).hasConnectorBelow))break;o.unshift(r),e=c}let s=t;for(;s;){const c=s.nextElementSibling;if(!c||c.getAttribute("data-testid")!=="cellInnerDiv")break;const r=c.querySelector('[data-testid="tweet"]');if(!r)break;const{hasConnectorAbove:i}=S(r);if(!i)break;o.push(r),s=c}return o}function B(n,o,t){var r;if(n.classList.contains("xfc-tweet"))return;const e=document.createElement("div");e.className="xfc-tweet-container",(r=n.parentNode)==null||r.insertBefore(e,n),e.appendChild(n);const s=document.createElement("div");s.className="xfc-controls",e.appendChild(s);const c=document.createElement("button");if(c.className="xfc-show-tweet-button",c.textContent="Show",s.appendChild(c),o){const i=document.createElement("div");i.className="xfc-reasons",i.textContent=o,s.appendChild(i)}if(t){const i=document.createElement("button");i.className="xfc-show-tweet-button",i.textContent="📋 Copy Debug",i.style.fontSize="11px",i.style.padding="4px 8px",s.appendChild(i),i.addEventListener("click",a=>{a.preventDefault(),a.stopPropagation();const h=t.images.length>0?`
IMAGES SENT (${t.images.length}):
${t.images.join(`
`)}
`:`
IMAGES SENT: none
`,d=`=== XFeedCleaner Debug Info ===

SYSTEM PROMPT:
${t.prompt}

TWEET TEXT SENT:
${t.tweetText}
${h}
MODEL RESPONSE:
${t.rawResponse}
`;navigator.clipboard.writeText(d).then(()=>{i.textContent="✓ Copied!",setTimeout(()=>{i.textContent="📋 Copy Debug"},2e3)})})}n.classList.add("xfc-tweet"),n.style.filter="blur(12px)",c.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),n.style.filter="none",n.classList.remove("xfc-tweet"),s.remove()})}function O(n){n.classList.contains("xfc-tweet")||n.classList.add("xfc-tweet","hidden-tweet")}function H(){const o=getComputedStyle(document.body).backgroundColor.match(/\d+/g);if(o){const[t,e,s]=o.map(Number);return(t+e+s)/3<128}return!1}function F(n,o,t,e){const s=n.closest("article");if(!s||s.hasAttribute("data-xfc-verdict"))return;s.setAttribute("data-xfc-verdict","true");const c=H(),r=document.createElement("div");r.className=`xfc-verdict-card ${o?"filtered":"allowed"}${c?" dark":""}`;const i=document.createElement("div");i.className="xfc-verdict-icon",i.textContent=o?"✗ Filtered":"✓ Allowed",r.appendChild(i);const a=document.createElement("div");if(a.className="xfc-verdict-reason",a.textContent=t||"analyzed",r.appendChild(a),e){const u=document.createElement("div");u.style.display="flex",u.style.gap="4px";const g=document.createElement("button");g.className="xfc-copy-debug",g.textContent="📝 Tweet",g.title="Copy tweet + AI decision",g.addEventListener("click",y=>{y.preventDefault(),y.stopPropagation();const E=e.images.length>0?`
Images: ${e.images.length}`:"",A=o?"FILTERED":"ALLOWED",k=`@${e.author}: ${e.tweetText}${E}

AI Decision: ${A} - "${t}"`;navigator.clipboard.writeText(k).then(()=>{g.textContent="✓",setTimeout(()=>{g.textContent="📝 Tweet"},1500)})}),u.appendChild(g);const w=document.createElement("button");w.className="xfc-copy-debug",w.textContent="🔧 Debug",w.title="Copy full debug info",w.addEventListener("click",y=>{y.preventDefault(),y.stopPropagation();const E=e.images.length>0?`
IMAGES SENT (${e.images.length}):
${e.images.join(`
`)}
`:`
IMAGES SENT: none
`,A=`FILTER DECISION: ${o?"FILTERED":"ALLOWED"}
REASON: ${t}

PROMPT SENT:
${e.prompt}

TWEET TEXT SENT:
@${e.author}: ${e.tweetText}
${E}
MODEL RESPONSE:
${e.rawResponse}
`;navigator.clipboard.writeText(A).then(()=>{w.textContent="✓",setTimeout(()=>{w.textContent="🔧 Debug"},1500)})}),u.appendChild(w),r.appendChild(u)}document.body.appendChild(r);const h=()=>{const u=s.getBoundingClientRect();r.style.top=`${u.top+8}px`,r.style.left=`${u.right+12}px`};h();const d=()=>requestAnimationFrame(h);window.addEventListener("scroll",d,{passive:!0});const l=new MutationObserver(()=>{document.contains(s)||(r.remove(),window.removeEventListener("scroll",d),l.disconnect())});l.observe(document.body,{childList:!0,subtree:!0})}function N(){const n=document.querySelector('[data-testid="sidebarColumn"]');if(!n)return;['[data-testid="renew-subscription-module"]','[aria-label="Subscribe to Premium"]','[aria-label="Trending"]','[aria-label="Who to follow"]'].forEach(t=>{var s,c;const e=n.querySelector(t);if(e){let r=e.closest('[data-testid="sidebarColumn"] > div > div > div');r||(r=((c=(s=e.parentElement)==null?void 0:s.parentElement)==null?void 0:c.parentElement)||null),r&&r instanceof HTMLElement&&(r.style.display="none")}}),n.querySelectorAll('aside, [role="complementary"]').forEach(t=>{var s;const e=((s=t.textContent)==null?void 0:s.toLowerCase())||"";(e.includes("premium")||e.includes("subscribe")||e.includes("verified"))&&t instanceof HTMLElement&&(t.style.display="none")})}const R=new MutationObserver(()=>{N()});function X(){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{N(),R.observe(document.body,{childList:!0,subtree:!0})}):(N(),R.observe(document.body,{childList:!0,subtree:!0}))}const I=document.createElement("style");I.textContent=`
  #xfeedcleaner * {
    all: unset;
  }

  #xfeedcleaner ul {
    list-style-type: disc !important;
    margin: 0 !important;
    padding-left: 20px !important;
  }

  #xfeedcleaner li {
  display: list-item !important;
    margin: 0.5em 0 !important;
  }

  #xfeedcleaner a {
    cursor: pointer;
  }

  #xfeedcleaner hr {
    height: 1px !important;
    border: none !important;
    padding: 0 !important;
    background-color: var(--black) !important;
  }
`,document.head.appendChild(I);const D=document.createElement("link");D.type="text/css",D.rel="stylesheet",document.head.appendChild(D);const q=document.createElement("style");q.textContent=`
  .xfc-controls {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    z-index: 1000;
  }

  .xfc-show-tweet-button {
    background-color: white;
    color: black;
    padding: 8px 16px;
    border-radius: 20px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    cursor: pointer;
    font-family: system-ui;
  }

  .xfc-reasons {
    color: #666;
    font-size: 12px;
    text-align: center;
    white-space: nowrap;
    font-family: system-ui;
    background: rgba(255, 255, 255, 0.9);
    padding: 4px 8px;
    border-radius: 4px;
  }

  .xfc-tweet-container {
    position: relative;
  }

  .xfc-tweet.hidden-tweet {
    display: none !important;
  }

  .xfc-verdict-card {
    position: fixed;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 11px;
    padding: 6px 10px;
    border-radius: 6px;
    z-index: 9999;
    max-width: 180px;
    background: rgba(255, 255, 255, 0.95);
    border: 1px solid #e1e8ed;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    pointer-events: auto;
  }

  /* Dark mode styles */
  .xfc-verdict-card.dark {
    background: rgba(32, 35, 39, 0.95);
    border-color: #38444d;
    box-shadow: 0 1px 3px rgba(0,0,0,0.3);
  }

  .xfc-verdict-card .xfc-verdict-icon {
    font-weight: 600;
    margin-bottom: 4px;
  }

  .xfc-verdict-card.allowed .xfc-verdict-icon {
    color: #16a34a;
  }

  .xfc-verdict-card.filtered .xfc-verdict-icon {
    color: #dc2626;
  }

  .xfc-verdict-card .xfc-verdict-reason {
    color: #536471;
    font-size: 11px;
    line-height: 1.3;
    margin-bottom: 6px;
  }

  .xfc-verdict-card.dark .xfc-verdict-reason {
    color: #8b98a5;
  }

  .xfc-verdict-card .xfc-copy-debug {
    background: #f7f9fa;
    border: 1px solid #e1e8ed;
    border-radius: 4px;
    padding: 4px 6px;
    font-size: 10px;
    cursor: pointer;
    color: #536471;
    text-align: center;
    white-space: nowrap;
    flex: 1;
  }

  .xfc-verdict-card.dark .xfc-copy-debug {
    background: #2f3336;
    border-color: #38444d;
    color: #8b98a5;
  }

  .xfc-verdict-card .xfc-copy-debug:hover {
    background: #e8ebed;
  }

  .xfc-verdict-card.dark .xfc-copy-debug:hover {
    background: #3a3f42;
  }
`,document.head.appendChild(q),X();function C(...n){console.log("[xfc]",...n)}const L=new Map,$=new IntersectionObserver(n=>{n.forEach(o=>{const t=o.target;if(o.isIntersecting){if(!t.hasAttribute("data-processed")){const e=W(t),s=S(t);s.hasConnectorBelow&&t.setAttribute("data-has-connector-below","true"),C("Tweet processed:",{author:e.author,text:e.text.slice(0,50)+"...",threadInfo:s});let c=e.text;if(e.articleText&&(c+=` [Article: ${e.articleText}]`),s.hasConnectorAbove){const l=j(t);l.length>0&&(c=`${l.join(" ")} [Reply @${e.author}: ${e.text}]`,C("Combined context:",c.slice(0,150)+"...",`(${l.length} parents)`))}const r=t.closest('[data-testid="cellInnerDiv"]');let i=null,a=null;if(s.hasConnectorAbove&&r){const l=r.previousElementSibling;(l==null?void 0:l.getAttribute("data-testid"))==="cellInnerDiv"&&(i=l.querySelector('[data-testid="tweet"]'))}if(s.hasConnectorBelow&&r){const l=r.nextElementSibling;(l==null?void 0:l.getAttribute("data-testid"))==="cellInnerDiv"&&(a=l.querySelector('[data-testid="tweet"]'))}if(L.set(e.id,{element:t,parentElement:i,replyElement:a}),i){const l=i.getAttribute("data-tweet-id");if(l&&L.has(l)){const u=L.get(l);u.replyElement=t}}C("Stored connection:",{id:e.id,hasParent:!!i,hasReply:!!a,images:e.images.length}),c.trim().length>=5||e.images.length>0?chrome.runtime.sendMessage({action:"newTweet",content:{...e,text:c,isReply:s.hasConnectorAbove,hasReplyBelow:s.hasConnectorBelow}}):C("Skipping tweet with no content:",e.id),t.setAttribute("data-processed","true")}$.unobserve(t)}})},{threshold:.3,rootMargin:"100px"}),U=new MutationObserver(n=>{n.forEach(o=>{o.addedNodes.forEach(t=>{t instanceof HTMLElement&&t.querySelectorAll('[data-testid="tweet"]:not([data-processed])').forEach(s=>{$.observe(s)})})})});(window.location.hostname==="twitter.com"||window.location.hostname==="x.com")&&(U.observe(document.body,{childList:!0,subtree:!0}),document.querySelectorAll('[data-testid="tweet"]:not([data-processed])').forEach(o=>{$.observe(o)})),chrome.runtime.onMessage.addListener(n=>{if(n.action==="analysisResult"){const{tweetId:o,isBait:t,reason:e,debugInfo:s,error:c}=n.result;if(c){console.error(`Error analyzing tweet ${o}:`,c);return}const r=document.querySelector(`[data-tweet-id="${o}"]`);if(!r)return;F(r,t,e,s),t&&chrome.storage.sync.get(["displayMode"],i=>{const a=i.displayMode||"blur",h=G(r);C("Filtering thread:",{tweetId:o,threadSize:h.length,reason:e}),a==="blur"?B(r,e,s):O(r),h.forEach(d=>{d!==r&&(C("Hiding thread tweet"),a==="blur"?B(d,"Part of filtered thread"):O(d))})})}}),chrome.runtime.onMessage.addListener(n=>{n.action==="toggleExtension"&&(n.isEnabled||(document.querySelectorAll(".xfc-tweet").forEach(o=>{o.style.filter="none",o.classList.remove("xfc-tweet")}),document.querySelectorAll(".xfc-show-tweet-button").forEach(o=>{o.remove()})))})})();
