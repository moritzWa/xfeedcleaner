const m=`- The tweet is not interesting and just making a joke or pointing out something funny
- The tweet uses manipulative tactics to gain engagement (engagement bait)
- The tweet is political in nature. It discusses politics, government, political issues, parties, candidates, elections, or any other political topic, be it related to any country or region.
- The tweet discusses ideologies in relation to politics. Topics such as racism, communism, fascism, nationalism, immigration, anti-immigration, DEI, woke-ism, far-left, far-right, etc.
- The tweet is a low-effort reply (emoji-only, single word like "this", "lol", "+1", etc.)
- The tweet is shallow social commentary or poll-style engagement bait ("hot take", "agree or disagree?", "X vs Y" comparisons, "is this enough money?", generic lifestyle debates)
- The tweet is a generic complaint or status update with no substance ("is X down?", "ugh mondays", etc.)
- The tweet promotes events, meetups, or announcements unrelated to technology, startups, AI, or software engineering
- The tweet does not provide any novel insight, interesting information, technical content, or thought-provoking ideas
`,u="You are a tweet analyzer. Your job is to decide if the content of a tweet is met with the following criteria:",f=`
If any of the above criteria are met, the tweet should be considered bait.
Respond EXCLUSIVELY using one of these formats:
- "true: reason1, reason2, reason3" (if bait)
- "false" (if not bait)

Where reasons are 1-3 lowercase keywords from the criteria. Example responses:
"true: political, divisive"
"true: sensationalized, manipulative"
"false"`;function w(t){return`${u}

${t}

${f}`}typeof browser>"u"&&(globalThis.browser=chrome);async function y(t,o){try{console.log("Analyzing tweet:",{tweetId:o,text:t});const{groqApiKey:e,promptCriteria:r,selectedModel:i,isEnabled:n}=await browser.storage.sync.get(["groqApiKey","promptCriteria","selectedModel","isEnabled"]);if(console.log("Retrieved settings:",{hasApiKey:!!e,hasCriteria:!!r,model:i,isEnabled:n}),!e)throw new Error("Groq API key not found. Please set it in the extension settings.");const d=w(r||m),p=i||"gemma2-9b-it",s=await(await fetch("https://api.groq.com/openai/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"},body:JSON.stringify({model:p,messages:[{role:"system",content:d},{role:"user",content:t}],temperature:0,max_tokens:10})})).json();if(console.log("Groq API response:",s),!s||!s.choices||!s.choices[0]||!s.choices[0].message)return console.error("Invalid response from Groq:",s),{tweetId:o,isBait:!1,error:"Invalid API response"};const a=s.choices[0].message.content.toLowerCase().trim(),l=a.startsWith("true");let c=[];if(l){const g=a.split(":");g.length>1&&(c=g[1].split(",").map(h=>h.trim()).filter(Boolean))}return{tweetId:o,isBait:l,reasons:c}}catch(e){return console.error("Error analyzing tweet:",e),{tweetId:o,isBait:!1,error:e.message||"Unknown error"}}}browser.runtime.onMessage.addListener((t,o)=>(t.action==="newTweet"&&browser.storage.sync.get(["isEnabled"]).then(async e=>{if(!(e.isEnabled??!0))return;const i=t.content.id;y(t.content.text,i).then(n=>{console.log("Analysis result:",n),o.tab&&o.tab.id&&browser.tabs.sendMessage(o.tab.id,{action:"analysisResult",result:{tweetId:i,isBait:n.isBait,reasons:n.reasons,error:null}})})}),!0));browser.runtime.onInstalled.addListener(async()=>{const{promptCriteria:t,selectedModel:o}=await browser.storage.sync.get(["promptCriteria","selectedModel"]),e={...t?{}:{promptCriteria:m},...o?{}:{selectedModel:"gemma2-9b-it"},isEnabled:!0};Object.keys(e).length>0&&(await browser.storage.sync.set(e),console.log("Default settings set:",e))});
